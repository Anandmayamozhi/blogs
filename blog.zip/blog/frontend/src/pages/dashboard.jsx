import { useState } from "react";
import Sidebar from "./sidebar";


function Dashboard(){


    const [userdetails, GetLoginuserdetails] = useState([JSON.parse(sessionStorage.getItem("user"))])

    console.log(userdetails)
    return(
        <>

        <div className="row">
            <div className="col-md-2">
               <Sidebar />
            </div>
            <div className="col-md-8">
              <h1>DASHBOARD</h1>
              <h1>Welcome <span>{userdetails[0].username}</span></h1>
            </div>
        </div>
        
        
        </>
    )
}

export default Dashboard;