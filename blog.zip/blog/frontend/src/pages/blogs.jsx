import { useState } from "react"
import Sidebar from "./sidebar"


function Blogs(){


    const [userdetails, GetLoginuserdetails] = useState([JSON.parse(sessionStorage.getItem("user"))])

    return(
        <>
        <div className="row">
            <div className="col-md-2">
               <Sidebar />
            </div>
            <div className="col-md-8">
              <h1>DASHBOARD</h1>
              <div className="">
                <div className="row">
                    <div className="col">
                    <a >{userdetails[0].blogtitle}</a>

                    </div>
                    <div className="col">
                    <a  href="/view" className="btn btn-primary">View</a>
                    </div>
                </div>
              </div>
            </div>
            
        </div>
        </>
    )
}

export default Blogs