import { useState } from "react"
import Sidebar from "./sidebar"

function Viewpage(){

    const [userdetails, GetLoginuserdetails] = useState([JSON.parse(sessionStorage.getItem("user"))])
    return(
        <>
        <div className="row">
            <div className="col-md-4">
                <Sidebar />
            </div>
            <div className="col-md-8">
                <h1>YOUR BLOG CONTENT</h1>
            <div>
           {userdetails[0].username}
        </div>
            </div>
        </div>
        </>
    )
}

export  default Viewpage