import { useState } from "react";
import Sidebar from "./sidebar"
import axios from 'axios';

function CreateBlogs(){


    const [title, Gettitle] = useState("")
    const [content, Getcontent] = useState("")
    const [userdetails, GetLoginuserdetails] = useState([JSON.parse(sessionStorage.getItem("user"))])

    function Publish() {
        axios.get("http://localhost:8000/signup", {
             
                params:{
                    usertitle:title,
                usercontent:content,
                userid:userdetails[0].id 
                }    
    })
        .then(res => {
            if (res.data.status === "success") {
                console.log(res.data.message);
            } else {
                console.log(res.data.message);
            }
        })
        .catch(err => {
            console.log(err);
        });
    }

    return(
        <>
        <div className="row">
            <div className="col-md-2">
                <Sidebar />
            </div>
            <div className="col-md-8">
            <h1>BlOG TITLE</h1>
        <input type="text" onInput={(e)=>{
            Gettitle(e.target.value)
        }} className="form-control" />
        <h1>CONTENT</h1>
        <textarea name="" rows={20} onInput={(e)=>{
            Getcontent(e.target.value)
        }} className="form-control" id=""></textarea>
           <div className="d-grid">
           <button onClick={Publish} className="btn btn-primary">PUBLISH</button>
           </div>
            </div>
        </div>
        </>
    )
}

export default CreateBlogs

