import { useEffect, useState } from "react";
import axios from 'axios';

function Signup(){

    const [users, Getusers] = useState([])
    const [username, Getusername] = useState("")
    const [password, Getupassword] = useState("")

    useEffect(()=>{

        fetch("http://127.0.0.1:8000/")
        .then(res => res.json())
        .then(data => Getusers(data))
        .catch(err => console.log(err))

    },[])


    function Signupdetails(){

        const user = users.find(user => user.username === username && user.password === password);
        if(user){

            alert("Username already taken")

        }else{
            
            axios.get("http://localhost:8000/signup", {
             
                params:{
                    username:username,
                    password:password,
                }    
    })
        .then(res => {
            if (res.data.status === "success") {
                console.log(res.data.message);
            } else {
                console.log(res.data.message);
            }
        })
        .catch(err => {
            console.log(err);
        });
        }
    }

    return(
        <>
    <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
      <div className="card shadow-lg p-4" style={{ width: '100%', maxWidth: '400px' }}>
        <h3 className="text-center mb-4">SignUp</h3>
     
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Username</label>
            <input 
              type="text" 
              className="form-control" 
              id="email" 
              name="email"
              onChange={(e)=>{
                Getusername(e.target.value)
              }}
              required 
            />
          </div>
          <div className="mb-3">
            <label htmlFor="password" className="form-label">Password</label>
            <input 
              type="password" 
              className="form-control" 
              id="password" 
              name="password"
              onChange={(e)=>{
                Getupassword(e.target.value)
              }}
              required 
            />
          </div>
          <div className="d-grid">
            <button onClick={Signupdetails} className="btn btn-primary">Login</button>
          </div>
   
        <div className="mt-3 text-center">
          <small className="text-muted">Don't have an account? <a href="/login">Sign up</a></small>
        </div>
      </div>
    </div>
        </>
    )
}

export default Signup;

