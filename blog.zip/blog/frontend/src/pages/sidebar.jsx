

function Sidebar(){

    return(
        <>
        <ul className="nav flex-column">
            <li className="nav-item">
                <a href="/dashboard" className="nav-links btn">Dashboard</a>
            </li>
            <li className="nav-item pt-1">
                <a href="/blogs" className="nav-links btn">Your Blogs</a>
            </li>
            <li className="nav-item pt-1">
                <a href="/create-blog" className="nav-links btn">Create Blogs</a>
            </li>
            <li className="nav-item pt-1">
                <a href="/login" className="nav-links btn">Logout</a>
            </li>
        </ul>
        </>
    )
}

export default Sidebar;