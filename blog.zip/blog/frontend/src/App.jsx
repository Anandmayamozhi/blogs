import { useEffect, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, Route, Routes } from "react-router-dom"
import Login from './pages/login'
import Dashboard from './pages/dashboard'
import Blogs from './pages/blogs'
import CreateBlogs from './pages/createblogs'
import Viewpage from './pages/viewpage'
import Signup from './pages/signup'

function App() {
  

  return (
    <>
    <BrowserRouter>
    <Routes>
        <Route path='/login' element={<Login />} />
        <Route path='/dashboard' element={<Dashboard />} />
        <Route path='/blogs' element={<Blogs />} />
        <Route path='/create-blog' element={<CreateBlogs />} />
        <Route path='/view' element={<Viewpage />} />
        <Route path='/signup' element={<Signup />} />
    </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
