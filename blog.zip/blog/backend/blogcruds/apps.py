from django.apps import AppConfig


class BlogcrudsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'blogcruds'
