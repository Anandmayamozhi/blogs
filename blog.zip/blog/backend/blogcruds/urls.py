from django.urls import path
from . import views

urlpatterns = [
    path('',views.UsersDetails),
    path('signup',views.Signup)
]