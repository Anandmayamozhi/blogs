from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from . models import BlogsCrudMiddle
# Create your views here.
def UsersDetails(request):
    users = BlogsCrudMiddle.objects.all().values('id','username', 'password', 'name', 'blogtitle', 'blogcontent')

    return JsonResponse(list(users), safe=False)

 
def Signup(request):
    try:
        username = request.GET['username']
        password = request.GET['password']
        BlogsCrudMiddle(username = username, password = password, name = username, blogtitle = "", blogcontent = "").save()
        return JsonResponse({"message":"ok"})
    except Exception as e:
        print(e)
        return JsonResponse({"message":e})
# def Signup(request):
#     try:
#         title = request.GET['usertitle']
#         content = request.GET['usercontent']
#         id = request.GET['userid'] 
#         datas = BlogsCrudMiddle.objects.get(id = id)
#         datas.blogtitle = title
#         datas.blogcontent = content
#         datas.save()
#         return JsonResponse({"message":"ok"})
#     except Exception as e:
#         print(e)
#         return JsonResponse({"message":e})
    
# def Signup(request):
#     msg = request.GET.get('message')  # Safely get 'message'
#     print(msg)
#     return JsonResponse({
#         'status': 'success',
#         'message': 'Received: ' + str(msg)
#     })



