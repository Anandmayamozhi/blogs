from django.db import models

# Create your models here.

class BlogsCrudMiddle(models.Model):

    username = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    blogtitle = models.CharField(max_length=100)
    blogcontent = models.CharField(max_length=100)

    class Meta:
        db_table = "bolgcontents"
